#include <ctype.h>
#include "AepServiceCodes.h"

//无符号整型16位  
uint_16 aep_htons(uint_16 source)  
{  

	if(AEP_ENDIANNESS == AEP_BIG_ENDIAN)
		return source;
	else
		return (uint_16)( 0
		| ((source & 0x00ff) << 8)
		| ((source & 0xff00) >> 8) );  
}  

//无符号整型32位
uint_32 aep_htoni(uint_32 source)  
{  
	if(AEP_ENDIANNESS == AEP_BIG_ENDIAN)
		return source;
	else
		return 0
		| ((source & 0x000000ff) << 24)
		| ((source & 0x0000ff00) << 8)
		| ((source & 0x00ff0000) >> 8)
		| ((source & 0xff000000) >> 24);  
}

//无符号整型64位
uint_64 aep_htonl(uint_64 source)  
{  
	if(AEP_ENDIANNESS == AEP_BIG_ENDIAN)
		return source;
	else
		return 0
		| ((source & (uint_64)(0x00000000000000ff)) << 56)
		| ((source & (uint_64)(0x000000000000ff00)) << 40)
		| ((source & (uint_64)(0x0000000000ff0000)) << 24)
		| ((source & (uint_64)(0x00000000ff000000)) << 8)
		| ((source & (uint_64)(0x000000ff00000000)) >> 8)
		| ((source & (uint_64)(0x0000ff0000000000)) >> 24)
		| ((source & (uint_64)(0x00ff000000000000)) >> 40)
		| ((source & (uint_64)(0xff00000000000000)) >> 56);
}

//float
float aep_htonf(float source)  
{  
	if(AEP_ENDIANNESS == AEP_BIG_ENDIAN)
		return source;
	else
	{
		uint_32 t= 0
			| ((*(uint_32*)&source & 0x000000ff) << 24)
			| ((*(uint_32*)&source & 0x0000ff00) << 8)
			| ((*(uint_32*)&source & 0x00ff0000) >> 8)
			| ((*(uint_32*)&source & 0xff000000) >> 24);
		return *(float*)&t;
	} 
}

//double
double aep_htond(double source)  
{  
	if(AEP_ENDIANNESS == AEP_BIG_ENDIAN)
		return source;
	else
	{
		uint_64 t= 0
			| ((*(uint_64*)&source & (uint_64)(0x00000000000000ff)) << 56)
			| ((*(uint_64*)&source & (uint_64)(0x000000000000ff00)) << 40)
			| ((*(uint_64*)&source & (uint_64)(0x0000000000ff0000)) << 24)
			| ((*(uint_64*)&source & (uint_64)(0x00000000ff000000)) << 8)
			| ((*(uint_64*)&source & (uint_64)(0x000000ff00000000)) >> 8)
			| ((*(uint_64*)&source & (uint_64)(0x0000ff0000000000)) >> 24)
			| ((*(uint_64*)&source & (uint_64)(0x00ff000000000000)) >> 40)
			| ((*(uint_64*)&source & (uint_64)(0xff00000000000000)) >> 56);
		return *(double*)&t;
	}
}

//16进制转字符串
void HexToStr(char *pbDest, char *pbSrc, int nLen)
{
	unsigned char ddl,ddh;
	int i;

	for (i=0; i<nLen; i++)
	{
		ddh = 48 + (unsigned char)pbSrc[i] / 16;
		ddl = 48 + (unsigned char)pbSrc[i] % 16;
		if (ddh > 57) ddh = ddh + 7;
		if (ddl > 57) ddl = ddl + 7;
		pbDest[i*2] = ddh;
		pbDest[i*2+1] = ddl;
	}

	//pbDest[nLen*2] = '\0';
}

//字符串转16进制
void StrToHex(char *pbDest, char *pbSrc, int nLen)
{
	unsigned char h1,h2;
	unsigned char s1,s2;
	int i;

	for (i=0; i<nLen; i++)
	{
		h1 = pbSrc[2*i];
		h2 = pbSrc[2*i+1];

		s1 = toupper(h1) - 0x30;
		if (s1 > 9) 
			s1 -= 7;

		s2 = toupper(h2) - 0x30;
		if (s2 > 9) 
			s2 -= 7;

		pbDest[i] = s1*16 + s2;
	}
}

//指令下发:报警模式控制
int alert_data_control_DecodeCmdDown (char* source, alert_data_control* dest)
{
	char* index = source;
	int srcStrLen = strlen(source);
	int len = 1;


	memset(dest, 0, sizeof(alert_data_control));

	StrToHex((char *)&dest->alert_data, index, 1);
	index += 1 * 2;



	if (len * 2 > srcStrLen)
	{
		return AEP_CMD_PAYLOAD_PARSING_FAILED;
	}
	return AEP_CMD_SUCCESS;
}

//指令下发响应:报警模式控制响应
AepString alert_data_resp_CodeCmdResponse (alert_data_resp srcStruct)
{
	char* index;
	AepString resultStruct;
	unsigned short tempLen;

	unsigned short payloadLen = 1;
	resultStruct.len = (1 + 2 + 2 + 2 + payloadLen) * 2;
	resultStruct.str = (char *)malloc(resultStruct.len + 1);
	memset(resultStruct.str, 0, resultStruct.len + 1);


	index = resultStruct.str;

	memcpy(index, "86", 2);
	index += 1 * 2;

	tempLen = aep_htons(9006);//服务ID
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	tempLen = aep_htons(srcStruct.taskId);//taskID
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	tempLen = aep_htons(payloadLen);
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	HexToStr(index, (char *)&srcStruct.alert_data, 1);
	index += 1 * 2;


	return resultStruct;
}

//事件上报:报警模式红外
AepString alert_warning_CodeEventReport (alert_warning srcStruct)
{
	char* index;
	AepString resultStruct;
	unsigned short tempLen;

	unsigned short payloadLen = 1;
	resultStruct.len = (1 + 2 + 2 + payloadLen) * 2;
	resultStruct.str = (char *)malloc(resultStruct.len + 1);
	memset(resultStruct.str, 0, resultStruct.len + 1);


	index = resultStruct.str;

	memcpy(index, "07", 2);
	index += 1 * 2;

	tempLen = aep_htons(1111);//服务ID
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	tempLen = aep_htons(payloadLen);
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	HexToStr(index, (char *)&srcStruct.warning_detect, 1);
	index += 1 * 2;


	return resultStruct;
}

//指令下发:自动灌溉模式控制
int autowatering_cmd_DecodeCmdDown (char* source, autowatering_cmd* dest)
{
	char* index = source;
	int srcStrLen = strlen(source);
	int len = 1;


	memset(dest, 0, sizeof(autowatering_cmd));

	StrToHex((char *)&dest->autowatering, index, 1);
	index += 1 * 2;



	if (len * 2 > srcStrLen)
	{
		return AEP_CMD_PAYLOAD_PARSING_FAILED;
	}
	return AEP_CMD_SUCCESS;
}

//指令下发响应:自动灌溉模式控制响应
AepString autowatering_rep_CodeCmdResponse (autowatering_rep srcStruct)
{
	char* index;
	AepString resultStruct;
	unsigned short tempLen;

	unsigned short payloadLen = 1;
	resultStruct.len = (1 + 2 + 2 + 2 + payloadLen) * 2;
	resultStruct.str = (char *)malloc(resultStruct.len + 1);
	memset(resultStruct.str, 0, resultStruct.len + 1);


	index = resultStruct.str;

	memcpy(index, "86", 2);
	index += 1 * 2;

	tempLen = aep_htons(9007);//服务ID
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	tempLen = aep_htons(srcStruct.taskId);//taskID
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	tempLen = aep_htons(payloadLen);
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	HexToStr(index, (char *)&srcStruct.autowatering, 1);
	index += 1 * 2;


	return resultStruct;
}

//事件上报:自动灌溉上报
AepString autowatering_upload_CodeEventReport (autowatering_upload srcStruct)
{
	char* index;
	AepString resultStruct;
	unsigned short tempLen;

	unsigned short payloadLen = 1;
	resultStruct.len = (1 + 2 + 2 + payloadLen) * 2;
	resultStruct.str = (char *)malloc(resultStruct.len + 1);
	memset(resultStruct.str, 0, resultStruct.len + 1);


	index = resultStruct.str;

	memcpy(index, "07", 2);
	index += 1 * 2;

	tempLen = aep_htons(1007);//服务ID
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	tempLen = aep_htons(payloadLen);
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	HexToStr(index, (char *)&srcStruct.autowatering_data, 1);
	index += 1 * 2;


	return resultStruct;
}

//数据上报:温湿度上报
AepString data_report_CodeDataReport (data_report srcStruct)
{
	char* index;
	AepString resultStruct;
	unsigned short tempLen;

	unsigned short payloadLen = 8;
	resultStruct.len = (1 + 2 + 2 + payloadLen) * 2;
	resultStruct.str = (char *)malloc(resultStruct.len + 1);
	memset(resultStruct.str, 0, resultStruct.len + 1);

	srcStruct.temperature_data = aep_htonf(srcStruct.temperature_data);
	srcStruct.humidity_data = aep_htoni(srcStruct.humidity_data);

	index = resultStruct.str;

	memcpy(index, "02", 2);
	index += 1 * 2;

	tempLen = aep_htons(1);//服务ID
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	tempLen = aep_htons(payloadLen);
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	HexToStr(index, (char *)&srcStruct.temperature_data, 4);
	index += 4 * 2;

	HexToStr(index, (char *)&srcStruct.humidity_data, 4);
	index += 4 * 2;


	return resultStruct;
}

//数据上报:设备信息上报
AepString info_report_CodeDataReport (info_report srcStruct)
{
	char* index;
	AepString resultStruct;
	unsigned short tempLen;

	unsigned short payloadLen = 0 + (srcStruct.hardware_version.len + 2) + (srcStruct.software_version.len + 2) + (srcStruct.IMEI.len + 2) + (srcStruct.ICCID.len + 2);
	resultStruct.len = (1 + 2 + 2 + payloadLen) * 2;
	resultStruct.str = (char *)malloc(resultStruct.len + 1);
	memset(resultStruct.str, 0, resultStruct.len + 1);


	index = resultStruct.str;

	memcpy(index, "02", 2);
	index += 1 * 2;

	tempLen = aep_htons(3);//服务ID
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	tempLen = aep_htons(payloadLen);
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	tempLen = aep_htons(srcStruct.hardware_version.len);
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;
	HexToStr(index, (char *)srcStruct.hardware_version.str, srcStruct.hardware_version.len);
	index += srcStruct.hardware_version.len * 2;

	tempLen = aep_htons(srcStruct.software_version.len);
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;
	HexToStr(index, (char *)srcStruct.software_version.str, srcStruct.software_version.len);
	index += srcStruct.software_version.len * 2;

	tempLen = aep_htons(srcStruct.IMEI.len);
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;
	HexToStr(index, (char *)srcStruct.IMEI.str, srcStruct.IMEI.len);
	index += srcStruct.IMEI.len * 2;

	tempLen = aep_htons(srcStruct.ICCID.len);
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;
	HexToStr(index, (char *)srcStruct.ICCID.str, srcStruct.ICCID.len);
	index += srcStruct.ICCID.len * 2;


	return resultStruct;
}

//事件上报:红外传感器上报
AepString ir_sensor_report_CodeEventReport (ir_sensor_report srcStruct)
{
	char* index;
	AepString resultStruct;
	unsigned short tempLen;

	unsigned short payloadLen = 1;
	resultStruct.len = (1 + 2 + 2 + payloadLen) * 2;
	resultStruct.str = (char *)malloc(resultStruct.len + 1);
	memset(resultStruct.str, 0, resultStruct.len + 1);


	index = resultStruct.str;

	memcpy(index, "07", 2);
	index += 1 * 2;

	tempLen = aep_htons(1001);//服务ID
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	tempLen = aep_htons(payloadLen);
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	HexToStr(index, (char *)&srcStruct.ir_sensor_data, 1);
	index += 1 * 2;


	return resultStruct;
}

//指令下发:警报开启
int motor_control_cmd_DecodeCmdDown (char* source, motor_control_cmd* dest)
{
	char* index = source;
	int srcStrLen = strlen(source);
	int len = 1;


	memset(dest, 0, sizeof(motor_control_cmd));

	StrToHex((char *)&dest->motor_control, index, 1);
	index += 1 * 2;



	if (len * 2 > srcStrLen)
	{
		return AEP_CMD_PAYLOAD_PARSING_FAILED;
	}
	return AEP_CMD_SUCCESS;
}

//指令下发响应:警报控制响应
AepString motor_control_resp_CodeCmdResponse (motor_control_resp srcStruct)
{
	char* index;
	AepString resultStruct;
	unsigned short tempLen;

	unsigned short payloadLen = 2;
	resultStruct.len = (1 + 2 + 2 + 2 + payloadLen) * 2;
	resultStruct.str = (char *)malloc(resultStruct.len + 1);
	memset(resultStruct.str, 0, resultStruct.len + 1);


	index = resultStruct.str;

	memcpy(index, "86", 2);
	index += 1 * 2;

	tempLen = aep_htons(9001);//服务ID
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	tempLen = aep_htons(srcStruct.taskId);//taskID
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	tempLen = aep_htons(payloadLen);
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	HexToStr(index, (char *)&srcStruct.motor_control, 1);
	index += 1 * 2;

	HexToStr(index, (char *)&srcStruct.act_result, 1);
	index += 1 * 2;


	return resultStruct;
}

//指令下发:温湿度自动上报设置
int set_auto_control_DecodeCmdDown (char* source, set_auto_control* dest)
{
	char* index = source;
	int srcStrLen = strlen(source);
	int len = 1;


	memset(dest, 0, sizeof(set_auto_control));

	StrToHex((char *)&dest->auto_control, index, 1);
	index += 1 * 2;



	if (len * 2 > srcStrLen)
	{
		return AEP_CMD_PAYLOAD_PARSING_FAILED;
	}
	return AEP_CMD_SUCCESS;
}

//指令下发响应:温湿度自动上报设置响应
AepString set_auto_control_resp_CodeCmdResponse (set_auto_control_resp srcStruct)
{
	char* index;
	AepString resultStruct;
	unsigned short tempLen;

	unsigned short payloadLen = 2;
	resultStruct.len = (1 + 2 + 2 + 2 + payloadLen) * 2;
	resultStruct.str = (char *)malloc(resultStruct.len + 1);
	memset(resultStruct.str, 0, resultStruct.len + 1);


	index = resultStruct.str;

	memcpy(index, "86", 2);
	index += 1 * 2;

	tempLen = aep_htons(9002);//服务ID
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	tempLen = aep_htons(srcStruct.taskId);//taskID
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	tempLen = aep_htons(payloadLen);
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	HexToStr(index, (char *)&srcStruct.auto_control, 1);
	index += 1 * 2;

	HexToStr(index, (char *)&srcStruct.act_result, 1);
	index += 1 * 2;


	return resultStruct;
}

//指令下发:温湿度上报周期配置
int set_report_period_DecodeCmdDown (char* source, set_report_period* dest)
{
	char* index = source;
	int srcStrLen = strlen(source);
	int len = 4;


	memset(dest, 0, sizeof(set_report_period));

	StrToHex((char *)&dest->report_period, index, 4);
	dest->report_period = aep_htoni(dest->report_period);
	index += 4 * 2;



	if (len * 2 > srcStrLen)
	{
		return AEP_CMD_PAYLOAD_PARSING_FAILED;
	}
	return AEP_CMD_SUCCESS;
}

//指令下发响应:温湿度上报周期配置响应
AepString set_report_period_resp_CodeCmdResponse (set_report_period_resp srcStruct)
{
	char* index;
	AepString resultStruct;
	unsigned short tempLen;

	unsigned short payloadLen = 5;
	resultStruct.len = (1 + 2 + 2 + 2 + payloadLen) * 2;
	resultStruct.str = (char *)malloc(resultStruct.len + 1);
	memset(resultStruct.str, 0, resultStruct.len + 1);

	srcStruct.report_period = aep_htoni(srcStruct.report_period);

	index = resultStruct.str;

	memcpy(index, "86", 2);
	index += 1 * 2;

	tempLen = aep_htons(9003);//服务ID
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	tempLen = aep_htons(srcStruct.taskId);//taskID
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	tempLen = aep_htons(payloadLen);
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	HexToStr(index, (char *)&srcStruct.report_period, 4);
	index += 4 * 2;

	HexToStr(index, (char *)&srcStruct.act_result, 1);
	index += 1 * 2;


	return resultStruct;
}

//数据上报:信号数据上报
AepString signal_report_CodeDataReport (signal_report srcStruct)
{
	char* index;
	AepString resultStruct;
	unsigned short tempLen;

	unsigned short payloadLen = 20;
	resultStruct.len = (1 + 2 + 2 + payloadLen) * 2;
	resultStruct.str = (char *)malloc(resultStruct.len + 1);
	memset(resultStruct.str, 0, resultStruct.len + 1);

	srcStruct.rsrp = aep_htoni(srcStruct.rsrp);
	srcStruct.sinr = aep_htoni(srcStruct.sinr);
	srcStruct.pci = aep_htoni(srcStruct.pci);
	srcStruct.ecl = aep_htoni(srcStruct.ecl);
	srcStruct.cell_id = aep_htoni(srcStruct.cell_id);

	index = resultStruct.str;

	memcpy(index, "02", 2);
	index += 1 * 2;

	tempLen = aep_htons(2);//服务ID
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	tempLen = aep_htons(payloadLen);
	HexToStr(index, (char *)&tempLen, 2);
	index += 2 * 2;

	HexToStr(index, (char *)&srcStruct.rsrp, 4);
	index += 4 * 2;

	HexToStr(index, (char *)&srcStruct.sinr, 4);
	index += 4 * 2;

	HexToStr(index, (char *)&srcStruct.pci, 4);
	index += 4 * 2;

	HexToStr(index, (char *)&srcStruct.ecl, 4);
	index += 4 * 2;

	HexToStr(index, (char *)&srcStruct.cell_id, 4);
	index += 4 * 2;


	return resultStruct;
}

AepCmdData decodeCmdDownFromStr(char* source)
{
	char* index;
	AepCmdData result;
	char cmdType;
	unsigned short serviceId;
	unsigned short payloadLen;

	memset(&result, 0, sizeof(AepCmdData));

	index = source;

	//解析指令类型
	StrToHex(&cmdType, index, 1);
	index += 1 * 2;
	if (cmdType != 0x06)
	{
		result.code = AEP_CMD_INVALID_DATASET_TYPE;
	}

	//服务Id解析
	StrToHex((char *)&serviceId, index, 2);
	serviceId = aep_htons(serviceId);
	index += 2 * 2;

	StrToHex((char *)&result.taskId, index, 2);
	result.taskId = aep_htons(result.taskId);
	index += 2 * 2;

	//payload长度解析
	StrToHex((char *)&payloadLen, index, 2);
	payloadLen = aep_htons(payloadLen);
	index += 2 * 2;

	if (strlen(index) < payloadLen * 2)
	{
		result.code = AEP_CMD_PAYLOAD_PARSING_FAILED;
		return result;
	}


	if (serviceId == 8006)
	{
		result.serviceIdentifier = "alert_data_control";
		result.data = malloc(sizeof(alert_data_control));
		memset(result.data, 0, sizeof(alert_data_control));
		result.code = alert_data_control_DecodeCmdDown(index, (alert_data_control*)result.data);
	}
	else if (serviceId == 8007)
	{
		result.serviceIdentifier = "autowatering_cmd";
		result.data = malloc(sizeof(autowatering_cmd));
		memset(result.data, 0, sizeof(autowatering_cmd));
		result.code = autowatering_cmd_DecodeCmdDown(index, (autowatering_cmd*)result.data);
	}
	else if (serviceId == 8001)
	{
		result.serviceIdentifier = "motor_control_cmd";
		result.data = malloc(sizeof(motor_control_cmd));
		memset(result.data, 0, sizeof(motor_control_cmd));
		result.code = motor_control_cmd_DecodeCmdDown(index, (motor_control_cmd*)result.data);
	}
	else if (serviceId == 8002)
	{
		result.serviceIdentifier = "set_auto_control";
		result.data = malloc(sizeof(set_auto_control));
		memset(result.data, 0, sizeof(set_auto_control));
		result.code = set_auto_control_DecodeCmdDown(index, (set_auto_control*)result.data);
	}
	else if (serviceId == 8003)
	{
		result.serviceIdentifier = "set_report_period";
		result.data = malloc(sizeof(set_report_period));
		memset(result.data, 0, sizeof(set_report_period));
		result.code = set_report_period_DecodeCmdDown(index, (set_report_period*)result.data);
	}
	else 
	{
		result.serviceIdentifier = NULL;
		result.data = malloc(payloadLen);
		memset(result.data, 0, sizeof(payloadLen));
		StrToHex((char *)result.data, index, payloadLen);
		result.code = AEP_CMD_INVALID_DATASET_IDENTIFIER;
	}

	return result;
}

AepCmdData decodeCmdDownFromBytes(char* source, int len)
{
	char * str = malloc(len * 2 + 1);
	AepCmdData result;
	HexToStr(str, source, len);
	str[len * 2] = 0;
	
	result = decodeCmdDownFromStr(str);
	free(str);
	return result;
}

AepString codeDataReportByIdToStr (int serviceId, void * srcStruct)
{
	if (serviceId == 9006)
	{
		return alert_data_resp_CodeCmdResponse(*(alert_data_resp*)srcStruct);
	}
	else if (serviceId == 1111)
	{
		return alert_warning_CodeEventReport(*(alert_warning*)srcStruct);
	}
	else if (serviceId == 9007)
	{
		return autowatering_rep_CodeCmdResponse(*(autowatering_rep*)srcStruct);
	}
	else if (serviceId == 1007)
	{
		return autowatering_upload_CodeEventReport(*(autowatering_upload*)srcStruct);
	}
	else if (serviceId == 1)
	{
		return data_report_CodeDataReport(*(data_report*)srcStruct);
	}
	else if (serviceId == 3)
	{
		return info_report_CodeDataReport(*(info_report*)srcStruct);
	}
	else if (serviceId == 1001)
	{
		return ir_sensor_report_CodeEventReport(*(ir_sensor_report*)srcStruct);
	}
	else if (serviceId == 9001)
	{
		return motor_control_resp_CodeCmdResponse(*(motor_control_resp*)srcStruct);
	}
	else if (serviceId == 9002)
	{
		return set_auto_control_resp_CodeCmdResponse(*(set_auto_control_resp*)srcStruct);
	}
	else if (serviceId == 9003)
	{
		return set_report_period_resp_CodeCmdResponse(*(set_report_period_resp*)srcStruct);
	}
	else if (serviceId == 2)
	{
		return signal_report_CodeDataReport(*(signal_report*)srcStruct);
	}
	else 
	{
		AepString result = {0};
		return result;
	}
}

AepBytes codeDataReportByIdToBytes(int serviceId, void * srcStruct)
{
	AepString temp = codeDataReportByIdToStr(serviceId, srcStruct);
	AepBytes result = {0};
	result.len = temp.len / 2;
	if (result.len > 0)
	{
		result.str = malloc(result.len);
		StrToHex(result.str, temp.str, result.len);
		free(temp.str);
	}
	return result;
}

AepString codeDataReportByIdentifierToStr (char* serviceIdentifier, void * srcStruct)
{
	if (strcmp(serviceIdentifier, "alert_data_resp") == 0)
	{
		return alert_data_resp_CodeCmdResponse(*(alert_data_resp*)srcStruct);
	}
	else if (strcmp(serviceIdentifier, "alert_warning") == 0)
	{
		return alert_warning_CodeEventReport(*(alert_warning*)srcStruct);
	}
	else if (strcmp(serviceIdentifier, "autowatering_rep") == 0)
	{
		return autowatering_rep_CodeCmdResponse(*(autowatering_rep*)srcStruct);
	}
	else if (strcmp(serviceIdentifier, "autowatering_upload") == 0)
	{
		return autowatering_upload_CodeEventReport(*(autowatering_upload*)srcStruct);
	}
	else if (strcmp(serviceIdentifier, "data_report") == 0)
	{
		return data_report_CodeDataReport(*(data_report*)srcStruct);
	}
	else if (strcmp(serviceIdentifier, "info_report") == 0)
	{
		return info_report_CodeDataReport(*(info_report*)srcStruct);
	}
	else if (strcmp(serviceIdentifier, "ir_sensor_report") == 0)
	{
		return ir_sensor_report_CodeEventReport(*(ir_sensor_report*)srcStruct);
	}
	else if (strcmp(serviceIdentifier, "motor_control_resp") == 0)
	{
		return motor_control_resp_CodeCmdResponse(*(motor_control_resp*)srcStruct);
	}
	else if (strcmp(serviceIdentifier, "set_auto_control_resp") == 0)
	{
		return set_auto_control_resp_CodeCmdResponse(*(set_auto_control_resp*)srcStruct);
	}
	else if (strcmp(serviceIdentifier, "set_report_period_resp") == 0)
	{
		return set_report_period_resp_CodeCmdResponse(*(set_report_period_resp*)srcStruct);
	}
	else if (strcmp(serviceIdentifier, "signal_report") == 0)
	{
		return signal_report_CodeDataReport(*(signal_report*)srcStruct);
	}
	else 
	{
		AepString result = {0};
		return result;
	}
}

AepBytes codeDataReportByIdentifierToBytes(char* serviceIdentifier, void * srcStruct)
{
	AepString temp = codeDataReportByIdentifierToStr(serviceIdentifier, srcStruct);
	AepBytes result = {0};
	result.len = temp.len / 2;
	if (result.len > 0)
	{
		result.str = malloc(result.len);
		StrToHex(result.str, temp.str, result.len);
		free(temp.str);
	}
	return result;
}

