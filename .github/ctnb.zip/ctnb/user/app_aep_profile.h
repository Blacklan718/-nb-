#ifndef __APP_PROFILE_THREAD_H__
#define __APP_PROFILE_THREAD_H__
#include <stdbool.h>

void aep_thread_init(void);


void decode_aep_data(char *data);

void nb_update_reg(bool isReRegistered);
#endif
