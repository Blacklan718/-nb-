/***
*AepServiceCodes.h - 定义上下行数据的结构体，还有提供组装上行报文的函数和解析下行报文的函数
*
*Purpose:
*	1.数据结构体命名和平台定义的服务标识一致
*	2.codeDataReportByIdToStr、codeDataReportByIdToBytes、codeDataReportByIdentifierToStr、codeDataReportByIdentifierToBytes为组装上报数据的函数，具体说明见函数前的注释
*	3.decodeCmdDownFromStr、decodeCmdDownFromBytes为解析平台发送过来数据的函数，具体说明见函数前的注释
****/
#ifndef AEPSERVICECODES_H
#define AEPSERVICECODES_H

#include <stdlib.h>
#include <string.h>


#define AEP_BIG_ENDIAN 'b'
#define AEP_LITTLE_ENDIAN 'l'

static union { char c[4]; unsigned long mylong; } endian_test = {{ 'l', '?', '?', 'b' } };
#define AEP_ENDIANNESS ((char)endian_test.mylong)


typedef unsigned long long uint_64;
typedef unsigned int uint_32;  
typedef unsigned short uint_16;

//命令解析响应码
#define AEP_CMD_SUCCESS 0						//执行成功
#define AEP_CMD_FAILED 1						//执行失败
#define AEP_CMD_INVALID_DATASET_TYPE 2			//无效数据集类型
#define AEP_CMD_INVALID_DATASET_IDENTIFIER 3	//无效数据集标识
#define AEP_CMD_PAYLOAD_PARSING_FAILED 4		//指令数据集Payload解析失败,紧凑二进制编码内容长度不符等


typedef struct AepStrStruct
{
	unsigned short len;
	char* str;
} AepString;
typedef AepString AepBytes;

//无符号整型16位  
uint_16 aep_htons(uint_16 source);

//无符号整型32位
uint_32 aep_htoni(uint_32 source);

//无符号整型64位
uint_64 aep_htonl(uint_64 source);

//float
float aep_htonf(float source);

//double
double aep_htond(double source);

//16进制转字符串
void HexToStr(char *pbDest, char *pbSrc, int nLen);

//字符串转16进制
void StrToHex(char *pbDest, char *pbSrc, int nLen);


//根据服务id生成上报数据的十六进制字符串,srcStruct需要根据服务定义传入对应的类型,返回结果为字符串
AepString codeDataReportByIdToStr(int serviceId, void * srcStruct);

//根据服务id生成上报数据的字节流,srcStruct需要根据服务定义传入对应的类型,返回结果为字节流
AepBytes codeDataReportByIdToBytes(int serviceId, void * srcStruct);

//根据服务标识生成上报数据的十六进制字符串,srcStruct需要根据服务定义传入对应的类型,返回结果为字符串
AepString codeDataReportByIdentifierToStr(char * serviceIdentifier, void * srcStruct);

//根据服务标识生成上报数据的字节流,srcStruct需要根据服务定义传入对应的类型,返回结果为字节流
AepBytes codeDataReportByIdentifierToBytes(char * serviceIdentifier, void * srcStruct);

//指令解析返回结构体，data在使用时需要根据serviceId强转为对应类型
typedef struct CmdStruct 
{
	char* serviceIdentifier;
	unsigned short taskId;
	void * data;
	int code;
} AepCmdData;
//解析接受到的报文数据,入参为十六进制字符串
AepCmdData decodeCmdDownFromStr(char* source);
//解析接受到的报文数据,入参为原始字节流
AepCmdData decodeCmdDownFromBytes(char* source, int len);



typedef struct alert_data_controlStruct 
{
	char alert_data;
} alert_data_control;
//指令下发:报警模式控制
int alert_data_control_DecodeCmdDown (char* source, alert_data_control* dest);


typedef struct alert_data_respStruct 
{
	unsigned short taskId;
	char alert_data;
} alert_data_resp;
//指令下发响应:报警模式控制响应
AepString alert_data_resp_CodeCmdResponse (alert_data_resp srcStruct);


typedef struct alert_warningStruct 
{
	char warning_detect;
} alert_warning;
//事件上报:报警模式红外
AepString alert_warning_CodeEventReport (alert_warning srcStruct);


typedef struct autowatering_cmdStruct 
{
	char autowatering;
} autowatering_cmd;
//指令下发:自动灌溉模式控制
int autowatering_cmd_DecodeCmdDown (char* source, autowatering_cmd* dest);


typedef struct autowatering_repStruct 
{
	unsigned short taskId;
	char autowatering;
} autowatering_rep;
//指令下发响应:自动灌溉模式控制响应
AepString autowatering_rep_CodeCmdResponse (autowatering_rep srcStruct);


typedef struct autowatering_uploadStruct 
{
	char autowatering_data;
} autowatering_upload;
//事件上报:自动灌溉上报
AepString autowatering_upload_CodeEventReport (autowatering_upload srcStruct);


typedef struct data_reportStruct 
{
	float temperature_data;
	int humidity_data;
} data_report;
//数据上报:温湿度上报
AepString data_report_CodeDataReport (data_report srcStruct);


typedef struct info_reportStruct 
{
	AepString hardware_version;
	AepString software_version;
	AepString IMEI;
	AepString ICCID;
} info_report;
//数据上报:设备信息上报
AepString info_report_CodeDataReport (info_report srcStruct);


typedef struct ir_sensor_reportStruct 
{
	char ir_sensor_data;
} ir_sensor_report;
//事件上报:红外传感器上报
AepString ir_sensor_report_CodeEventReport (ir_sensor_report srcStruct);


typedef struct motor_control_cmdStruct 
{
	char motor_control;
} motor_control_cmd;
//指令下发:警报开启
int motor_control_cmd_DecodeCmdDown (char* source, motor_control_cmd* dest);


typedef struct motor_control_respStruct 
{
	unsigned short taskId;
	char motor_control;
	char act_result;
} motor_control_resp;
//指令下发响应:警报控制响应
AepString motor_control_resp_CodeCmdResponse (motor_control_resp srcStruct);


typedef struct set_auto_controlStruct 
{
	char auto_control;
} set_auto_control;
//指令下发:温湿度自动上报设置
int set_auto_control_DecodeCmdDown (char* source, set_auto_control* dest);


typedef struct set_auto_control_respStruct 
{
	unsigned short taskId;
	char auto_control;
	char act_result;
} set_auto_control_resp;
//指令下发响应:温湿度自动上报设置响应
AepString set_auto_control_resp_CodeCmdResponse (set_auto_control_resp srcStruct);


typedef struct set_report_periodStruct 
{
	int report_period;
} set_report_period;
//指令下发:温湿度上报周期配置
int set_report_period_DecodeCmdDown (char* source, set_report_period* dest);


typedef struct set_report_period_respStruct 
{
	unsigned short taskId;
	int report_period;
	char act_result;
} set_report_period_resp;
//指令下发响应:温湿度上报周期配置响应
AepString set_report_period_resp_CodeCmdResponse (set_report_period_resp srcStruct);


typedef struct signal_reportStruct 
{
	int rsrp;
	int sinr;
	int pci;
	int ecl;
	int cell_id;
} signal_report;
//数据上报:信号数据上报
AepString signal_report_CodeDataReport (signal_report srcStruct);



#endif
