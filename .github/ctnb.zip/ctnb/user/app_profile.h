#ifndef __APP_PROFILE_THREAD_H__
#define __APP_PROFILE_THREAD_H__

void app_profile_thread_init(void);

void decode_rev_data(char *revdata);

#endif
